import React from 'react';
import Button from '@material-ui/core/Button';
import { Grid } from '@material-ui/core';
import Paper from '@material-ui/core/Paper';
import { withStyles } from '@material-ui/core/styles';
import CustomInput from '../components-mui/CustomInput/CustomInput.js'
import InputAdornment from "@material-ui/core/InputAdornment";
import People from "@material-ui/icons/People";
import Icon from "@material-ui/core/Icon";
import LockIcon from '@material-ui/icons/Lock';
import axios from 'axios';


import stylin from "../assets/jss/material-kit-react/views/loginPage.js"
import image from "../assets/img/bg7.jpg";
import logo from "../images/logo.png";


const styles = theme => ({
    loginButton: {
        fontFamily: 'Karla, sans-serif',
        color: '#AAABBC',
        border: 'solid',
        borderColor: '#8B8982',
        backgroundColor: "#f5f5f5",
        fontSize: '1em',
        paddingTop: '1vh',
        paddingBottom: '1vh',
        textAlign: 'center'
    },
    iconPaper: {
        height: '20vh', // responsive height is 30vh, 180px
        borderStyle: 'solid',
        borderColor: '#8B8982',
        marginTop: '10vh',
        marginBottom: '5vh',
        
    },
    welcomePaper: {
        fontFamily: 'Karla, sans-serif',
        width: '25vw',
        borderStyle: 'solid',
        backgroundColor: "#f5f5f5",
        color: "#AAABBC",
        borderColor: '#8B8982',
        paddingRight: '5vw',
        paddingLeft: '5vw',
        textAlign: 'center',
        marginBottom: '5vh',
    },
    inputPaper: {
        border: 'solid',
        borderColor: '#59bf8e',
        color: '#3e8563',
        fontFamily: 'Karla, sans-serif',
        paddingRight: '3vw',
        paddingLeft: '3vw',
        paddingBottom: '3vh',
        marginBottom: '3vh',
        width: '40vw'
    },
    searchField: {
        color: '#3e8563',
        fontFamily: 'Karla, sans-serif',
    },
    searchFieldLabel: {
        color: '#3e8563',
        fontFamily: 'Karla, sans-serif',
    },
    searchUnderline: {
        color: 'red !important'
    }

})



export default withStyles(styles)(class LoginPage extends React.Component {

    state = {
        username: undefined,
        password: undefined,
        isClicked: false,
        data: undefined
    };

    getUsers = async () => {
        await axios.get(
            '/api/getUsers',
            {
                headers: {'Content-type': 'application/json'}
            }
        ).then((data) => {
            let details = data['data'];
            details.map((n) => {
                const full_name = n.firstname + " " + n.lastname;
                n['fullname'] = full_name;
            });
            this.setState({data: data['data']});
        })}

    handleUsernameChange = (e) => {
        this.setState({username: e.target.value});
        console.log(e.target.value);
    }

    handlePasswordChange = (e) => {
        this.setState({password: e.target.value});
        // <img className={classes.icon} src={logo} />
    }

    handleSubmit = (e) => {
        //this.getUsers();
        this.props.submitBehavior();
    }

    render() {
        
        const {classes} = this.props;
        return (
            <div>
                <Grid
                    container
                    spacing={0}
                    direction="column"
                    alignItems="center"
                    justify="center"
                >
                    <div>
                    <img className={classes.iconPaper} src={logo} />
                  </div>
                    <Paper color="primary" className={classes.welcomePaper}>
                        <div><h1>Welcome to <span style={{padding: 0, margin: 0, color: "#6C91C2"}}>id</span>ioma!</h1></div>
                    </Paper>

                    
                    
                    <Grid item xs={3} >
                        <Button className={classes.loginButton} variant="contained"  onClick={this.handleSubmit}>Log in with Auth0!</Button>
                    </Grid>
                    <Paper>
                         
                          {this.state.data && this.state.data[0]['f_name']}
                          {this.state.data && console.log(this.state.data[0])}
                    </Paper>
                </Grid>
            </div>
        )
    }
})