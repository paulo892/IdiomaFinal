import React, { Component } from 'react';
import App from '../App';
import LoginPage from './LoginPage';
import LogoutPage from './LogoutPage';

class Home extends Component {
  // calls the login method in authentication service
  login = () => {
    this.props.auth.login();
  }
  // calls the logout method in authentication service
  logout = () => {
    this.props.auth.logout();
  }
  render() {
    // calls the isAuthenticated method in authentication service
    const { isAuthenticated } = this.props.auth;
    return (
      <div>
        {
          !isAuthenticated() &&
          <LoginPage submitBehavior={this.login}/>
        }
        {
          isAuthenticated() &&
          <LogoutPage submitBehavior={this.logout}/>
        }
      </div>
      );
    }
  }

  export default Home;